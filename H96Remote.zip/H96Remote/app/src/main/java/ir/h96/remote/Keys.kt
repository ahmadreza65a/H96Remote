package ir.h96.remote

/**
 * Every remote key, with:
 *  - androidKey : Android KeyEvent code (used over Wi-Fi/ADB)
 *  - hidKeyboard: USB-HID keyboard usage (page 0x07), or 0
 *  - hidConsumer: USB-HID consumer usage (page 0x0C), or 0
 */
enum class RemoteKey(
    val label: String,
    val androidKey: Int,
    val hidKeyboard: Int = 0,
    val hidConsumer: Int = 0,
    val hidMod: Int = 0,          // keyboard modifier: 0x01 Ctrl, 0x02 Shift, 0x04 Alt
) {
    // Power/volume/back/home/menu are sent as KEYBOARD keys: every Android box accepts these.
    // Esc = Back, Alt+Esc = Home, Ctrl+Esc = Menu (Android's built-in keyboard fallbacks).
    POWER("پاور", 26, hidKeyboard = 0x66),
    UP("▲", 19, hidKeyboard = 0x52),
    DOWN("▼", 20, hidKeyboard = 0x51),
    LEFT("◀", 21, hidKeyboard = 0x50),
    RIGHT("▶", 22, hidKeyboard = 0x4F),
    OK("OK", 23, hidKeyboard = 0x28),
    BACK("بازگشت", 4, hidKeyboard = 0x29),
    HOME("خانه", 3, hidKeyboard = 0x29, hidConsumer = 0x223, hidMod = 0x04),
    MENU("منو", 82, hidKeyboard = 0x29, hidMod = 0x01),
    VOL_UP("صدا +", 24, hidKeyboard = 0x80),
    VOL_DOWN("صدا −", 25, hidKeyboard = 0x81),
    MUTE("بی‌صدا", 164, hidKeyboard = 0x7F),
    PLAY_PAUSE("⏯", 85, hidConsumer = 0xCD),
    NEXT("⏭", 87, hidConsumer = 0xB5),
    PREV("⏮", 88, hidConsumer = 0xB6),
    REWIND("⏪", 89, hidConsumer = 0xB4),
    FFWD("⏩", 90, hidConsumer = 0xB3),
    SEARCH("جستجو", 84, hidConsumer = 0x221),
}

/**
 * Persian char -> key position on the standard Persian layout (ISIRI 9147).
 * Works when the box's physical-keyboard layout is set to Persian.
 */
fun persianToHid(c: Char): Pair<Int, Boolean>? = when (c) {
    'ض' -> 0x14 to false; 'ص' -> 0x1A to false; 'ث' -> 0x08 to false; 'ق' -> 0x15 to false
    'ف' -> 0x17 to false; 'غ' -> 0x1C to false; 'ع' -> 0x18 to false; 'ه' -> 0x0C to false
    'خ' -> 0x12 to false; 'ح' -> 0x13 to false; 'ج' -> 0x2F to false; 'چ' -> 0x30 to false
    'ش' -> 0x04 to false; 'س' -> 0x16 to false; 'ی', 'ي' -> 0x07 to false; 'ب' -> 0x09 to false
    'ل' -> 0x0A to false; 'ا' -> 0x0B to false; 'ت' -> 0x0D to false; 'ن' -> 0x0E to false
    'م' -> 0x0F to false; 'ک', 'ك' -> 0x33 to false; 'گ' -> 0x34 to false
    'ظ' -> 0x1D to false; 'ط' -> 0x1B to false; 'ز' -> 0x06 to false; 'ر' -> 0x19 to false
    'ذ' -> 0x05 to false; 'د' -> 0x11 to false; 'پ' -> 0x10 to false; 'و' -> 0x36 to false
    'آ' -> 0x0B to true; 'ژ' -> 0x06 to true; '؟' -> 0x38 to true
    '‌' -> 0x2C to true   // نیم‌فاصله = Shift+Space
    in '۱'..'۹' -> (0x1E + (c - '۱')) to false
    '۰' -> 0x27 to false
    else -> null
}

/** ASCII char -> (HID keyboard usage, needs shift). */
fun charToHid(c: Char): Pair<Int, Boolean>? = when (c) {
    in 'a'..'z' -> (0x04 + (c - 'a')) to false
    in 'A'..'Z' -> (0x04 + (c - 'A')) to true
    in '1'..'9' -> (0x1E + (c - '1')) to false
    '0' -> 0x27 to false
    ' ' -> 0x2C to false
    '\n' -> 0x28 to false
    '!' -> 0x1E to true
    '@' -> 0x1F to true
    '#' -> 0x20 to true
    '$' -> 0x21 to true
    '%' -> 0x22 to true
    '^' -> 0x23 to true
    '&' -> 0x24 to true
    '*' -> 0x25 to true
    '(' -> 0x26 to true
    ')' -> 0x27 to true
    '-' -> 0x2D to false
    '_' -> 0x2D to true
    '=' -> 0x2E to false
    '+' -> 0x2E to true
    '[' -> 0x2F to false
    '{' -> 0x2F to true
    ']' -> 0x30 to false
    '}' -> 0x30 to true
    '\\' -> 0x31 to false
    '|' -> 0x31 to true
    ';' -> 0x33 to false
    ':' -> 0x33 to true
    '\'' -> 0x34 to false
    '"' -> 0x34 to true
    '`' -> 0x35 to false
    '~' -> 0x35 to true
    ',' -> 0x36 to false
    '<' -> 0x36 to true
    '.' -> 0x37 to false
    '>' -> 0x37 to true
    '/' -> 0x38 to false
    '?' -> 0x38 to true
    else -> null
}
