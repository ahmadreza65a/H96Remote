package ir.h96.remote

/**
 * Every remote key, with:
 *  - androidKey : Android KeyEvent code (used over Wi-Fi/ADB)
 *  - hidKeyboard: USB-HID keyboard usage (page 0x07), or 0
 *  - hidConsumer: USB-HID consumer usage (page 0x0C), or 0
 */
enum class RemoteKey(
    val label: String,
    val androidKey: Int,
    val hidKeyboard: Int = 0,
    val hidConsumer: Int = 0,
) {
    POWER("پاور", 26, hidConsumer = 0x30),
    UP("▲", 19, hidKeyboard = 0x52),
    DOWN("▼", 20, hidKeyboard = 0x51),
    LEFT("◀", 21, hidKeyboard = 0x50),
    RIGHT("▶", 22, hidKeyboard = 0x4F),
    OK("OK", 23, hidKeyboard = 0x28),
    BACK("بازگشت", 4, hidConsumer = 0x224),
    HOME("خانه", 3, hidConsumer = 0x223),
    MENU("منو", 82, hidConsumer = 0x40),
    VOL_UP("صدا +", 24, hidConsumer = 0xE9),
    VOL_DOWN("صدا −", 25, hidConsumer = 0xEA),
    MUTE("بی‌صدا", 164, hidConsumer = 0xE2),
    PLAY_PAUSE("⏯", 85, hidConsumer = 0xCD),
    NEXT("⏭", 87, hidConsumer = 0xB5),
    PREV("⏮", 88, hidConsumer = 0xB6),
    REWIND("⏪", 89, hidConsumer = 0xB4),
    FFWD("⏩", 90, hidConsumer = 0xB3),
    SEARCH("جستجو", 84, hidConsumer = 0x221),
}

/** ASCII char -> (HID keyboard usage, needs shift). */
fun charToHid(c: Char): Pair<Int, Boolean>? = when (c) {
    in 'a'..'z' -> (0x04 + (c - 'a')) to false
    in 'A'..'Z' -> (0x04 + (c - 'A')) to true
    in '1'..'9' -> (0x1E + (c - '1')) to false
    '0' -> 0x27 to false
    ' ' -> 0x2C to false
    '\n' -> 0x28 to false
    '!' -> 0x1E to true
    '@' -> 0x1F to true
    '#' -> 0x20 to true
    '$' -> 0x21 to true
    '%' -> 0x22 to true
    '^' -> 0x23 to true
    '&' -> 0x24 to true
    '*' -> 0x25 to true
    '(' -> 0x26 to true
    ')' -> 0x27 to true
    '-' -> 0x2D to false
    '_' -> 0x2D to true
    '=' -> 0x2E to false
    '+' -> 0x2E to true
    '[' -> 0x2F to false
    '{' -> 0x2F to true
    ']' -> 0x30 to false
    '}' -> 0x30 to true
    '\\' -> 0x31 to false
    '|' -> 0x31 to true
    ';' -> 0x33 to false
    ':' -> 0x33 to true
    '\'' -> 0x34 to false
    '"' -> 0x34 to true
    '`' -> 0x35 to false
    '~' -> 0x35 to true
    ',' -> 0x36 to false
    '<' -> 0x36 to true
    '.' -> 0x37 to false
    '>' -> 0x37 to true
    '/' -> 0x38 to false
    '?' -> 0x38 to true
    else -> null
}
