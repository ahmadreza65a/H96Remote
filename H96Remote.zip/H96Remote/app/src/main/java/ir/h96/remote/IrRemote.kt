package ir.h96.remote

import android.content.Context
import android.content.SharedPreferences
import android.hardware.ConsumerIrManager
import java.util.concurrent.Executors

/** One IR code set: NEC address bytes (b0, b1, as sent on air) + command byte per key. */
class IrProfile(
    val name: String,
    var b0: Int,
    var b1: Int,
    val codes: MutableMap<RemoteKey, Int>,
) {
    fun toText(): String = buildString {
        append("address=%02X %02X\n".format(b0, b1))
        for ((k, v) in codes) append("%s=%02X\n".format(k.name, v))
    }

    fun copy(newName: String) = IrProfile(newName, b0, b1, codes.toMutableMap())

    companion object {
        /** Format:  address=40 40   then lines like  POWER=B2 */
        fun parse(name: String, text: String): IrProfile {
            val p = IrProfile(name, 0x40, 0x40, mutableMapOf())
            for (raw in text.lines()) {
                val line = raw.trim()
                if (line.isEmpty() || line.startsWith("#") || !line.contains('=')) continue
                val (k, v) = line.split('=', limit = 2).map { it.trim() }
                if (k.equals("address", true)) {
                    val parts = v.replace("0x", "", true).split(' ', ',', ':').filter { it.isNotBlank() }
                    if (parts.size == 1 && parts[0].length == 4) {
                        p.b0 = parts[0].substring(0, 2).toInt(16)
                        p.b1 = parts[0].substring(2, 4).toInt(16)
                    } else if (parts.size >= 2) {
                        p.b0 = parts[0].toInt(16); p.b1 = parts[1].toInt(16)
                    }
                } else {
                    val key = RemoteKey.entries.firstOrNull { it.name.equals(k, true) } ?: continue
                    val code = v.replace("0x", "", true).toIntOrNull(16) ?: continue
                    p.codes[key] = code and 0xFF
                }
            }
            return p
        }
    }
}

class IrRemote(ctx: Context, private val prefs: SharedPreferences) {
    private val ir = ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    private val exec = Executors.newSingleThreadExecutor()

    val available: Boolean get() = try { ir?.hasIrEmitter() == true } catch (e: Exception) { false }

    /**
     * Presets taken from the Rockchip reference IR keymaps that most RK-based TV boxes
     * (H96 MAX M-series) ship with. If none of them work, use the code scanner.
     */
    val presets: List<IrProfile> = listOf(
        IrProfile("Rockchip ۱ (4040)", 0x40, 0x40, mutableMapOf(
            RemoteKey.POWER to 0xB2, RemoteKey.UP to 0xF4, RemoteKey.DOWN to 0xF1,
            RemoteKey.LEFT to 0xEF, RemoteKey.RIGHT to 0xEE, RemoteKey.OK to 0xF2,
            RemoteKey.BACK to 0xBA, RemoteKey.HOME to 0xBD, RemoteKey.MENU to 0xEC,
            RemoteKey.VOL_UP to 0xEA, RemoteKey.VOL_DOWN to 0xE3, RemoteKey.MUTE to 0xBC,
            RemoteKey.SEARCH to 0xE2,
        )),
        IrProfile("Rockchip ۲ (FF00)", 0x00, 0xFF, mutableMapOf(
            RemoteKey.POWER to 0xE7, RemoteKey.UP to 0xB9, RemoteKey.DOWN to 0xE9,
            RemoteKey.LEFT to 0xB8, RemoteKey.RIGHT to 0xEA, RemoteKey.OK to 0xAA,
            RemoteKey.BACK to 0xBF, RemoteKey.HOME to 0xF9, RemoteKey.MENU to 0xFB,
            RemoteKey.VOL_UP to 0xEF, RemoteKey.VOL_DOWN to 0xEB, RemoteKey.MUTE to 0xF7,
        )),
        IrProfile("Rockchip ۳ (1DCC)", 0xCC, 0x1D, mutableMapOf(
            RemoteKey.POWER to 0xFF, RemoteKey.UP to 0xF8, RemoteKey.DOWN to 0xBB,
            RemoteKey.LEFT to 0xEF, RemoteKey.RIGHT to 0xED, RemoteKey.OK to 0xEE,
            RemoteKey.BACK to 0xF0, RemoteKey.HOME to 0xFC, RemoteKey.MENU to 0xBF,
            RemoteKey.VOL_UP to 0xF1, RemoteKey.VOL_DOWN to 0xFD, RemoteKey.MUTE to 0xF3,
            RemoteKey.SEARCH to 0xB7,
        )),
        IrProfile("Rockchip ۳ معکوس (CC1D)", 0x1D, 0xCC, mutableMapOf(
            RemoteKey.POWER to 0xFF, RemoteKey.UP to 0xF8, RemoteKey.DOWN to 0xBB,
            RemoteKey.LEFT to 0xEF, RemoteKey.RIGHT to 0xED, RemoteKey.OK to 0xEE,
            RemoteKey.BACK to 0xF0, RemoteKey.HOME to 0xFC, RemoteKey.MENU to 0xBF,
            RemoteKey.VOL_UP to 0xF1, RemoteKey.VOL_DOWN to 0xFD, RemoteKey.MUTE to 0xF3,
            RemoteKey.SEARCH to 0xB7,
        )),
    )

    var custom: IrProfile = IrProfile.parse("سفارشی", prefs.getString("ir_custom", null) ?: presets[0].toText())
        private set

    val all: List<IrProfile> get() = presets + custom

    var selectedIndex: Int
        get() = prefs.getInt("ir_profile", 0).coerceIn(0, all.size - 1)
        set(v) = prefs.edit().putInt("ir_profile", v).apply()

    val current: IrProfile get() = all[selectedIndex]

    fun saveCustom(p: IrProfile) {
        custom = IrProfile.parse("سفارشی", p.toText())
        prefs.edit().putString("ir_custom", custom.toText()).apply()
        selectedIndex = all.size - 1
    }

    fun has(key: RemoteKey) = current.codes.containsKey(key)

    fun send(key: RemoteKey, profile: IrProfile = current): Boolean {
        val code = profile.codes[key] ?: return false
        sendRaw(profile.b0, profile.b1, code)
        return true
    }

    fun sendRaw(b0: Int, b1: Int, cmd: Int) {
        val pattern = necPattern(intArrayOf(b0 and 0xFF, b1 and 0xFF, cmd and 0xFF, cmd.inv() and 0xFF))
        exec.execute {
            try { ir?.transmit(38000, pattern) } catch (_: Exception) { }
        }
    }

    /** NEC frame in microseconds: 9ms mark, 4.5ms space, 32 bits LSB-first, stop mark. */
    private fun necPattern(bytes: IntArray): IntArray {
        val p = ArrayList<Int>(68)
        p += 9000; p += 4500
        for (b in bytes) for (i in 0 until 8) {
            p += 562
            p += if (((b shr i) and 1) == 1) 1687 else 562
        }
        p += 562
        return p.toIntArray()
    }
}
