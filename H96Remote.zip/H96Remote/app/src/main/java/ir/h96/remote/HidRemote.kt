package ir.h96.remote

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/**
 * Turns the phone into a Bluetooth keyboard + mouse + media remote (HID Device profile).
 * The TV box sees it as a real Bluetooth mouse, so a real cursor appears: true air mouse.
 */
@SuppressLint("MissingPermission")
class HidRemote(ctx: Context, private val prefs: SharedPreferences) {
    var onState: (() -> Unit)? = null
    var status: String = "غیرفعال"
        private set

    private val manager = ctx.getSystemService(BluetoothManager::class.java)
    private val appCtx = ctx.applicationContext
    val adapter: BluetoothAdapter? get() = manager?.adapter

    private var hid: BluetoothHidDevice? = null
    var registered = false
        private set
    var device: BluetoothDevice? = null
        private set
    val isConnected get() = device != null

    private var pendingConnect: BluetoothDevice? = null
    private val cbExec = Executors.newSingleThreadExecutor()
    private val sendExec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private fun setStatus(s: String) {
        status = s
        main.post { onState?.invoke() }
    }

    fun name(d: BluetoothDevice): String = try { d.name ?: d.address } catch (e: SecurityException) { d.address }

    fun start() {
        val a = adapter ?: return setStatus("این گوشی بلوتوث ندارد")
        if (!a.isEnabled) return setStatus("بلوتوث خاموش است")
        if (hid != null) { if (!registered) register(); return }
        setStatus("در حال آماده‌سازی…")
        val ok = a.getProfileProxy(appCtx, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                hid = proxy as BluetoothHidDevice
                register()
            }
            override fun onServiceDisconnected(profile: Int) {
                hid = null; registered = false; device = null
                setStatus("سرویس HID قطع شد")
            }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) setStatus("گوشی شما از حالت ماوس/کیبورد بلوتوثی (HID) پشتیبانی نمی‌کند")
    }

    private fun register() {
        val sdp = BluetoothHidDeviceAppSdpSettings(
            "H96 Remote", "Air mouse + keyboard + remote", "H96Remote",
            BluetoothHidDevice.SUBCLASS1_COMBO, DESCRIPTOR
        )
        val ok = try { hid?.registerApp(sdp, null, null, cbExec, callback) == true } catch (e: Exception) { false }
        if (!ok) setStatus("ثبت HID ناموفق بود (شاید برنامه‌ی دیگری از آن استفاده می‌کند)")
    }

    fun connect(d: BluetoothDevice) {
        val h = hid
        if (h == null || !registered) { pendingConnect = d; start(); return }
        setStatus("در حال اتصال به ${name(d)}…")
        if (!h.connect(d)) setStatus("اتصال شروع نشد؛ ابتدا باکس را با گوشی جفت (Pair) کنید")
    }

    fun disconnect() { device?.let { hid?.disconnect(it) } }

    fun stop() {
        try { hid?.unregisterApp() } catch (_: Exception) { }
        try { hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } } catch (_: Exception) { }
        hid = null; registered = false; device = null
        setStatus("غیرفعال")
    }

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, reg: Boolean) {
            registered = reg
            if (!reg) { device = null; setStatus("ثبت نشد / لغو شد"); return }
            setStatus("آماده — منتظر اتصال باکس")
            val target = pendingConnect ?: pluggedDevice ?: savedDevice()
            pendingConnect = null
            if (target != null) try { hid?.connect(target) } catch (_: Exception) { }
        }

        override fun onConnectionStateChanged(d: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    device = d
                    prefs.edit().putString("bt_last", d.address).apply()
                    setStatus("متصل به ${name(d)}")
                }
                BluetoothProfile.STATE_CONNECTING -> setStatus("در حال اتصال به ${name(d)}…")
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (device == null || device?.address == d.address) device = null
                    setStatus("قطع شد — آماده برای اتصال دوباره")
                }
            }
        }

        override fun onGetReport(d: BluetoothDevice, type: Byte, id: Byte, bufferSize: Int) {
            val size = when (id.toInt()) { 1 -> 8; 2 -> 4; else -> 2 }
            hid?.replyReport(d, type, id, ByteArray(size))
        }

        override fun onSetReport(d: BluetoothDevice, type: Byte, id: Byte, data: ByteArray) {
            hid?.reportError(d, BluetoothHidDevice.ERROR_RSP_SUCCESS)
        }
    }

    private fun savedDevice(): BluetoothDevice? {
        val addr = prefs.getString("bt_last", null) ?: return null
        return try { adapter?.bondedDevices?.firstOrNull { it.address == addr } } catch (e: Exception) { null }
    }

    fun bondedDevices(): List<BluetoothDevice> =
        try { adapter?.bondedDevices?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }

    // ---------- reports ----------
    private fun report(id: Int, data: ByteArray): Boolean {
        val d = device ?: return false
        return try { hid?.sendReport(d, id, data) == true } catch (e: Exception) { false }
    }

    fun sendKey(k: RemoteKey): Boolean {
        if (!isConnected) return false
        sendExec.execute {
            if (k.hidKeyboard != 0) {
                val mod = k.hidMod.toByte()
                if (k.hidMod != 0) { report(1, byteArrayOf(mod, 0, 0, 0, 0, 0, 0, 0)); Thread.sleep(10) }
                report(1, byteArrayOf(mod, 0, k.hidKeyboard.toByte(), 0, 0, 0, 0, 0))
                Thread.sleep(15)
                if (k.hidMod != 0) { report(1, byteArrayOf(mod, 0, 0, 0, 0, 0, 0, 0)); Thread.sleep(10) }
                report(1, ByteArray(8))
            }
            // Home is also sent as a media key (pressing Home twice is harmless).
            if (k.hidConsumer != 0) {
                Thread.sleep(10)
                report(3, byteArrayOf((k.hidConsumer and 0xFF).toByte(), (k.hidConsumer shr 8).toByte()))
                Thread.sleep(15)
                report(3, ByteArray(2))
            }
        }
        return true
    }

    fun typeKeyCode(usage: Int, shift: Boolean = false) {
        if (!isConnected) return
        sendExec.execute { tap(usage, shift) }
    }

    /** Ctrl+Space: switches the box's physical keyboard layout (English <-> Persian). */
    fun switchLanguage() {
        if (!isConnected) return
        sendExec.execute {
            report(1, byteArrayOf(0x01, 0, 0x2C, 0, 0, 0, 0, 0))
            Thread.sleep(20)
            report(1, ByteArray(8))
        }
    }

    private fun tap(usage: Int, shift: Boolean) {
        val mod: Byte = if (shift) 0x02 else 0
        report(1, byteArrayOf(mod, 0, usage.toByte(), 0, 0, 0, 0, 0))
        Thread.sleep(8)
        report(1, ByteArray(8))
        Thread.sleep(8)
    }

    /** Types ASCII text. Returns count of chars that could not be typed. */
    fun typeText(s: String): Int {
        if (!isConnected) return s.length
        var skipped = 0
        val list = s.mapNotNull { c -> charToHid(c) ?: persianToHid(c) ?: run { skipped++; null } }
        sendExec.execute { for ((u, sh) in list) tap(u, sh) }
        return skipped
    }

    fun move(dx: Int, dy: Int, wheel: Int = 0, buttons: Int = 0) {
        if (!isConnected) return
        val x = dx.coerceIn(-127, 127).toByte()
        val y = dy.coerceIn(-127, 127).toByte()
        val w = wheel.coerceIn(-127, 127).toByte()
        sendExec.execute { report(2, byteArrayOf(buttons.toByte(), x, y, w)) }
    }

    /** button: 1 = left, 2 = right, 4 = middle */
    fun click(button: Int) {
        if (!isConnected) return
        sendExec.execute {
            report(2, byteArrayOf(button.toByte(), 0, 0, 0))
            Thread.sleep(25)
            report(2, ByteArray(4))
        }
    }

    companion object {
        /** Composite HID: keyboard (id 1), mouse (id 2), consumer/media (id 3). */
        val DESCRIPTOR: ByteArray = intArrayOf(
            // Keyboard
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x26, 0xFF, 0x00, 0x05, 0x07, 0x19, 0x00, 0x2A, 0xFF, 0x00, 0x81, 0x00,
            0xC0,
            // Mouse
            0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x85, 0x02, 0x09, 0x01, 0xA1, 0x00,
            0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, 0x95, 0x03, 0x75, 0x01, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x05, 0x81, 0x01,
            0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06,
            0xC0, 0xC0,
            // Consumer control (media, home, back, power…)
            0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x03,
            0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03, 0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
            0xC0,
        ).map { it.toByte() }.toByteArray()
    }
}
