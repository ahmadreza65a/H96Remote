package ir.h96.remote

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class MainActivity : Activity(), SensorEventListener {

    private enum class Channel(val label: String) { AUTO("خودکار"), IR("IR"), BT("بلوتوث"), WIFI("وای‌فای") }

    private val app get() = App.instance
    private val ir get() = app.ir
    private val hid get() = app.hid
    private val adb get() = app.adb
    private val prefs get() = app.prefs
    private val handler = Handler(Looper.getMainLooper())

    private var channel = Channel.AUTO
    private lateinit var statusText: TextView
    private val channelChips = mutableListOf<TextView>()
    private val tabChips = mutableListOf<TextView>()
    private val panels = mutableListOf<View>()
    private var dialogStatus: TextView? = null

    // mouse
    private lateinit var sensorManager: SensorManager
    private var gyro: Sensor? = null
    private var airMode = false
    private var mouseTabVisible = false
    private var sensitivity = 1.0f
    private var lastGyroTs = 0L
    private var accX = 0f
    private var accY = 0f
    private var accWheel = 0f
    private val modeChips = mutableListOf<TextView>()
    private var lastBtWarn = 0L

    // ------------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        channel = Channel.entries[prefs.getInt("channel", 0).coerceIn(0, 3)]
        sensitivity = prefs.getFloat("sens", 1.0f)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        setContentView(buildUi())

        hid.onState = { refreshStatus() }
        adb.onState = { refreshStatus() }
        refreshStatus()

        // Re-arm Bluetooth remote automatically if it was used before.
        if (prefs.getString("bt_last", null) != null && hasBtPermissions()) {
            if (hid.adapter?.isEnabled == true) hid.start()
        }
        // Reconnect Wi-Fi automatically.
        prefs.getString("adb_host", null)?.let { if (it.isNotBlank() && !adb.connected) adb.connectAsync(it, prefs.getInt("adb_port", 5555)) }
    }

    override fun onResume() { super.onResume(); updateSensor() }
    override fun onPause() { super.onPause(); sensorManager.unregisterListener(this) }

    override fun onDestroy() {
        super.onDestroy()
        hid.onState = null; adb.onState = null
        if (isFinishing) hid.stop()
    }

    /** Phone volume keys control the box volume when something is connected. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val any = hid.isConnected || adb.connected
        if (any && prefs.getBoolean("vol_keys", true)) {
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) { sendKey(RemoteKey.VOL_UP); return true }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) { sendKey(RemoteKey.VOL_DOWN); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------ routing
    private fun sendKey(key: RemoteKey) {
        val ok = when (channel) {
            Channel.IR -> ir.available && ir.send(key)
            Channel.BT -> hid.sendKey(key)
            Channel.WIFI -> adb.sendKey(key)
            Channel.AUTO -> when {
                hid.isConnected -> hid.sendKey(key)
                // Box asleep (no Bluetooth/Wi-Fi): only IR can wake it.
                key == RemoteKey.POWER && ir.available && ir.has(key) -> ir.send(key)
                adb.connected -> adb.sendKey(key)
                ir.available && ir.has(key) -> ir.send(key)
                else -> false
            }
        }
        if (!ok) {
            val msg = when {
                channel == Channel.IR && !ir.available -> "این گوشی فرستنده‌ی IR ندارد"
                channel == Channel.IR -> "کد IR این دکمه در پروفایل فعلی نیست (از «IR» → اسکنر کد استفاده کنید)"
                channel == Channel.BT -> "بلوتوث وصل نیست"
                channel == Channel.WIFI -> "وای‌فای وصل نیست"
                else -> "ابتدا یکی از اتصال‌ها را برقرار کنید"
            }
            toast(msg)
        }
    }

    // ------------------------------------------------------------------ UI
    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(10), dp(12), dp(8))
        }

        root.addView(TextView(this).apply {
            text = "H96 MAX M9 — ریموت"
            setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
        })
        statusText = TextView(this).apply {
            setTextColor(C_DIM); textSize = 12f; setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(statusText)

        // Channel selector
        root.addView(label("مسیر ارسال دکمه‌ها:"))
        val chRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in Channel.entries) {
            val chip = chip(c.label) { channel = c; prefs.edit().putInt("channel", c.ordinal).apply(); paintChips() }
            channelChips += chip
            chRow.addView(chip, weighted(40))
        }
        root.addView(chRow)

        // Connection setup
        root.addView(label("راه‌اندازی اتصال:"))
        root.addView(row(40,
            btn("📡 IR", C_CARD2, 14f) { showIrDialog() },
            btn("🔵 بلوتوث", C_CARD2, 14f) { showBtDialog() },
            btn("📶 وای‌فای", C_CARD2, 14f) { showWifiDialog() },
        ))

        // Tabs
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(6)) }
        val tabNames = listOf("🎮 ریموت", "🖱 ایرماوس", "⌨ کیبورد")
        tabNames.forEachIndexed { i, n ->
            val t = chip(n) { selectTab(i) }
            tabChips += t
            tabRow.addView(t, weighted(42))
        }
        root.addView(tabRow)

        val content = FrameLayout(this)
        panels += remotePanel()
        panels += mousePanel()
        panels += keyboardPanel()
        panels.forEach { content.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        paintChips()
        selectTab(prefs.getInt("tab", 0))
        return root
    }

    private fun selectTab(i: Int) {
        prefs.edit().putInt("tab", i).apply()
        panels.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
        tabChips.forEachIndexed { j, t -> t.background = bg(if (i == j) C_ACCENT else C_CARD, 20) }
        mouseTabVisible = i == 1
        updateSensor()
    }

    private fun paintChips() {
        channelChips.forEachIndexed { j, t -> t.background = bg(if (channel.ordinal == j) C_ACCENT else C_CARD, 20) }
        modeChips.forEachIndexed { j, t -> t.background = bg(if ((j == 1) == airMode) C_ACCENT else C_CARD, 20) }
    }

    private fun refreshStatus() {
        val irS = if (ir.available) "✓ ${ir.current.name}" else "✗ ندارد"
        val btS = hid.status
        val wfS = adb.status
        val s = "IR: $irS\nبلوتوث: $btS\nوای‌فای: $wfS"
        statusText.text = s
        dialogStatus?.text = s
    }

    // ---------------- remote panel
    private fun remotePanel(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(row(52,
            keyBtn(RemoteKey.POWER, "⏻ پاور", C_RED),
            keyBtn(RemoteKey.MUTE, "🔇 بی‌صدا"),
            keyBtn(RemoteKey.SEARCH, "🔍 جستجو"),
        ))
        col.addView(space(10))
        // D-pad (LTR so left/right are physical)
        val pad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        pad.addView(row(68, space(1), keyBtn(RemoteKey.UP, repeat = true, textSize = 22f), space(1)))
        pad.addView(row(68,
            keyBtn(RemoteKey.LEFT, repeat = true, textSize = 22f),
            keyBtn(RemoteKey.OK, color = C_ACCENT, textSize = 20f),
            keyBtn(RemoteKey.RIGHT, repeat = true, textSize = 22f)))
        pad.addView(row(68, space(1), keyBtn(RemoteKey.DOWN, repeat = true, textSize = 22f), space(1)))
        col.addView(pad)
        col.addView(space(10))
        col.addView(row(52,
            keyBtn(RemoteKey.BACK, "↩ بازگشت"),
            keyBtn(RemoteKey.HOME, "⌂ خانه"),
            keyBtn(RemoteKey.MENU, "☰ منو"),
        ))
        col.addView(row(52,
            keyBtn(RemoteKey.VOL_DOWN, repeat = true),
            keyBtn(RemoteKey.VOL_UP, repeat = true),
        ))
        val media = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        media.addView(row(52,
            keyBtn(RemoteKey.PREV, textSize = 20f), keyBtn(RemoteKey.REWIND, repeat = true, textSize = 20f),
            keyBtn(RemoteKey.PLAY_PAUSE, textSize = 20f),
            keyBtn(RemoteKey.FFWD, repeat = true, textSize = 20f), keyBtn(RemoteKey.NEXT, textSize = 20f),
        ))
        col.addView(media)
        col.addView(TextView(this).apply {
            text = "نکته: دکمه‌های صدای گوشی هم صدای باکس را کم و زیاد می‌کنند."
            setTextColor(C_DIM); textSize = 12f; setPadding(dp(4), dp(10), dp(4), dp(10))
        })
        return ScrollView(this).apply { addView(col) }
    }

    // ---------------- mouse panel
    @SuppressLint("ClickableViewAccessibility")
    private fun mousePanel(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tp = chip("☝ تاچ‌پد") { airMode = false; paintChips(); updateSensor() }
        val am = chip("✈ ایرماوس (ژیروسکوپ)") {
            if (gyro == null) toast("این گوشی ژیروسکوپ ندارد؛ از حالت تاچ‌پد استفاده کنید")
            else { airMode = true; paintChips(); updateSensor() }
        }
        modeChips += tp; modeChips += am
        modeRow.addView(tp, weighted(40)); modeRow.addView(am, weighted(40))
        col.addView(modeRow)

        val sensLabel = label("حساسیت: %.1f".format(sensitivity))
        col.addView(sensLabel)
        col.addView(SeekBar(this).apply {
            max = 30; progress = (sensitivity * 10).toInt().coerceIn(2, 30)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                    sensitivity = p.coerceAtLeast(2) / 10f
                    sensLabel.text = "حساسیت: %.1f".format(sensitivity)
                    prefs.edit().putFloat("sens", sensitivity).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })

        val pad = TouchPadView(this).apply {
            onDrag = { dx, dy, fingers ->
                if (checkBtForMouse()) {
                    if (airMode || fingers >= 2) scrollBy(dy) else {
                        accX += dx * 1.6f * sensitivity; accY += dy * 1.6f * sensitivity
                        flushMove()
                    }
                }
            }
            onTap = { fingers -> if (checkBtForMouse()) hid.click(if (fingers >= 2) 2 else 1) }
        }
        col.addView(pad, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(6), 0, dp(6)) })

        col.addView(row(50,
            btn("کلیک", C_ACCENT) { if (checkBtForMouse()) hid.click(1) },
            btn("کلیک راست", C_CARD) { if (checkBtForMouse()) hid.click(2) },
            btn("▲ اسکرول", C_CARD) { if (checkBtForMouse()) hid.move(0, 0, 2) },
            btn("▼ اسکرول", C_CARD) { if (checkBtForMouse()) hid.move(0, 0, -2) },
        ))
        col.addView(TextView(this).apply {
            text = "ایرماوس: گوشی را مثل ریموت به طرف تلویزیون بگیرید و بچرخانید. ضربه روی صفحه = کلیک، کشیدن انگشت = اسکرول.\n" +
                "تاچ‌پد: کشیدن یک انگشت = حرکت، دو انگشت = اسکرول، ضربه‌ی دو انگشتی = کلیک راست.\n" +
                "ماوس فقط از طریق بلوتوث کار می‌کند."
            setTextColor(C_DIM); textSize = 12f
        })
        return col
    }

    private fun checkBtForMouse(): Boolean {
        if (hid.isConnected) return true
        val now = System.currentTimeMillis()
        if (now - lastBtWarn > 3000) { lastBtWarn = now; toast("برای ماوس، ابتدا از دکمه‌ی «بلوتوث» وصل شوید") }
        return false
    }

    private fun flushMove() {
        val ix = accX.toInt().coerceIn(-127, 127)
        val iy = accY.toInt().coerceIn(-127, 127)
        if (ix != 0 || iy != 0) {
            hid.move(ix, iy)
            accX -= ix; accY -= iy
        }
    }

    private fun scrollBy(dyPx: Float) {
        accWheel += -dyPx / dp(28)
        val w = accWheel.toInt()
        if (w != 0) { hid.move(0, 0, w); accWheel -= w }
    }

    private fun updateSensor() {
        sensorManager.unregisterListener(this)
        if (airMode && mouseTabVisible && gyro != null) {
            lastGyroTs = 0L
            sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type != Sensor.TYPE_GYROSCOPE) return
        if (lastGyroTs == 0L) { lastGyroTs = e.timestamp; return }
        val dt = (e.timestamp - lastGyroTs) / 1e9f
        lastGyroTs = e.timestamp
        if (dt <= 0f || dt > 0.1f || !hid.isConnected) return
        var wz = e.values[2]   // turn left/right (yaw)
        var wx = e.values[0]   // tilt up/down (pitch)
        val dead = 0.015f
        if (abs(wz) < dead) wz = 0f
        if (abs(wx) < dead) wx = 0f
        val gain = 1100f * sensitivity
        accX += -wz * dt * gain
        accY += -wx * dt * gain
        flushMove()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // ---------------- keyboard panel
    private fun keyboardPanel(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val edit = EditText(this).apply {
            hint = "متن فارسی یا انگلیسی را بنویسید"
            setHintTextColor(C_DIM); setTextColor(Color.WHITE)
            background = bg(C_CARD, 12); setPadding(dp(12), dp(12), dp(12), dp(12))
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        col.addView(edit, LinearLayout.LayoutParams(-1, -2))
        val live = CheckBox(this).apply {
            text = "تایپ زنده (هر حرف بلافاصله ارسال شود)"
            setTextColor(Color.WHITE); isChecked = prefs.getBoolean("live", true)
            buttonTintList = ColorStateList.valueOf(C_ACCENT)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("live", c).apply() }
        }
        col.addView(live)

        var old = ""
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val now = s?.toString() ?: ""
                if (live.isChecked) {
                    when {
                        now.startsWith(old) -> typeText(now.substring(old.length))
                        old.startsWith(now) -> repeat(old.length - now.length) { backspace() }
                        else -> { repeat(old.length) { backspace() }; typeText(now) }
                    }
                }
                old = now
            }
        })

        col.addView(space(8))
        col.addView(row(50,
            btn("ارسال", C_ACCENT) { if (!live.isChecked) typeText(edit.text.toString()); old = ""; edit.setText("") ; old = "" },
            btn("⌫", C_CARD) { backspace() },
            btn("Enter ↵", C_CARD) { enter() },
            btn("فاصله", C_CARD) { typeText(" ") },
        ))
        col.addView(row(50,
            btn("پاک کردن کادر", C_CARD2) { live.isChecked.let { l -> live.isChecked = false; edit.setText(""); old = ""; live.isChecked = l } },
            btn("Tab", C_CARD) { if (hid.isConnected) hid.typeKeyCode(0x2B) else adb.keyCode(61) },
        ))
        col.addView(row(50,
            btn("🌐 فارسی ⇄ انگلیسی (بلوتوث)", C_ACCENT, 14f) {
                if (hid.isConnected) { hid.switchLanguage(); toast("زبان کیبورد باکس عوض شد (Ctrl+Space)") }
                else toast("این دکمه برای حالت بلوتوث است")
            },
        ))
        col.addView(row(50,
            btn("فعال‌سازی فارسی وای‌فای", C_CARD2, 13f) { enableAdbKeyboard() },
            btn("کیبورد قبلی باکس", C_CARD2, 13f) { if (adb.connected) { adb.shellAsync("ime reset"); toast("کیبورد پیش‌فرض باکس برگشت") } else toast("وای‌فای وصل نیست") },
        ))
        col.addView(TextView(this).apply {
            text = "کیبورد از طریق بلوتوث یا وای‌فای کار می‌کند (IR نمی‌تواند متن بفرستد).\n\n" +
                "فارسی با بلوتوث: یک بار روی باکس بروید به Settings ← System ← Keyboard (یا Languages & input) ← Physical keyboard ← H96 Remote و چیدمان‌های Persian و English (US) را فعال کنید. بعد با دکمه‌ی «فارسی ⇄ انگلیسی» زبان را عوض کنید.\n\n" +
                "فارسی با وای‌فای: برنامه‌ی ADBKeyBoard باید روی باکس نصب باشد، بعد «فعال‌سازی فارسی وای‌فای» را بزنید."
            setTextColor(C_DIM); textSize = 12f; setPadding(dp(4), dp(10), dp(4), 0)
        })
        return ScrollView(this).apply { addView(col) }
    }

    private fun useHidForText() = hid.isConnected && channel != Channel.WIFI

    private fun typeText(s: String) {
        if (s.isEmpty()) return
        when {
            useHidForText() -> { val skipped = hid.typeText(s); if (skipped > 0) toast("$skipped نویسه ارسال نشد (این حرف در چیدمان پشتیبانی نمی‌شود)") }
            adb.connected -> adb.typeText(s)
            else -> toast("برای تایپ، بلوتوث یا وای‌فای را وصل کنید")
        }
    }

    private fun enableAdbKeyboard() {
        if (!adb.connected) return toast("ابتدا وای‌فای را وصل کنید")
        adb.shellAsync("pm list packages com.android.adbkeyboard") { out ->
            if (out?.contains("com.android.adbkeyboard") == true) {
                adb.shellAsync("ime enable com.android.adbkeyboard/.AdbIME; ime set com.android.adbkeyboard/.AdbIME")
                toast("تایپ فارسی از طریق وای‌فای فعال شد")
            } else {
                AlertDialog.Builder(this, DIALOG_THEME)
                    .setTitle("ADBKeyBoard نصب نیست")
                    .setMessage("برای ارسال حروف فارسی از وای‌فای، برنامه‌ی رایگان ADBKeyBoard باید روی باکس نصب باشد.\n\n" +
                        "۱. فایل ADBKeyboard.apk را از صفحه‌ی github.com/senzhk/ADBKeyBoard (بخش Releases) دانلود کنید.\n" +
                        "۲. با فلش USB یا مرورگر باکس آن را روی باکس نصب کنید.\n" +
                        "۳. دوباره همین دکمه را بزنید.\n\n" +
                        "راه ساده‌تر: از حالت بلوتوث با چیدمان فارسی استفاده کنید.")
                    .setPositiveButton("باشه", null).show()
            }
        }
    }

    private fun backspace() { if (useHidForText()) hid.typeKeyCode(0x2A) else if (adb.connected) adb.keyCode(67) }
    private fun enter() { if (useHidForText()) hid.typeKeyCode(0x28) else if (adb.connected) adb.keyCode(66) }

    // ------------------------------------------------------------------ Bluetooth dialog
    private fun btPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
        else emptyArray()

    private fun hasBtPermissions() = btPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_BT) {
            if (hasBtPermissions()) showBtDialog() else toast("بدون مجوز بلوتوث، ایرماوس کار نمی‌کند")
        }
    }

    @SuppressLint("MissingPermission")
    private fun showBtDialog() {
        if (!hasBtPermissions()) { requestPermissions(btPermissions(), REQ_BT); return }
        val adapter = hid.adapter ?: return toast("این گوشی بلوتوث ندارد")
        if (!adapter.isEnabled) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            toast("بلوتوث را روشن کنید و دوباره «بلوتوث» را بزنید")
            return
        }
        hid.start()

        val col = dialogColumn()
        col.addView(info(
            "این حالت گوشی را برای باکس به یک «ماوس + کیبورد + ریموت بلوتوثی» واقعی تبدیل می‌کند؛ نشانگر ماوس روی تلویزیون ظاهر می‌شود و نیازی به نصب چیزی روی باکس نیست.\n\n" +
            "اولین بار (جفت کردن):\n" +
            "۱. دکمه‌ی «قابل‌شناسایی کردن گوشی» را بزنید.\n" +
            "۲. روی باکس (با دکمه‌های IR همین برنامه یا یک ماوس USB) بروید به:\n" +
            "   Settings ← Bluetooth (یا Remotes & Accessories) ← Pair new device / Add accessory\n" +
            "۳. نام گوشی خود را انتخاب و روی هر دو دستگاه تأیید کنید.\n" +
            "۴. اگر خودکار وصل نشد، نام باکس را از فهرست زیر بزنید.\n\n" +
            "دفعه‌های بعد: فقط نام باکس را از فهرست بزنید (برنامه خودش هم تلاش می‌کند وصل شود)."
        ))
        dialogStatus = statusBox(col)
        col.addView(row(46, btn("👁 قابل‌شناسایی کردن گوشی (۵ دقیقه)", C_ACCENT, 14f) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
        }))
        col.addView(label("دستگاه‌های جفت‌شده (برای اتصال بزنید):"))
        val devices = hid.bondedDevices()
        if (devices.isEmpty()) col.addView(info("هنوز دستگاهی جفت نشده است."))
        for (d in devices) col.addView(row(44, btn("🔗 " + hid.name(d), C_CARD, 14f) { hid.connect(d) }))
        col.addView(space(6))
        col.addView(row(44,
            btn("قطع اتصال", C_CARD2, 14f) { hid.disconnect() },
            btn("غیرفعال کردن کامل", C_RED, 14f) { hid.stop() },
        ))
        showDialog("ریموت و ایرماوس بلوتوثی", col)
    }

    // ------------------------------------------------------------------ Wi-Fi dialog
    private fun showWifiDialog() {
        val col = dialogColumn()
        col.addView(info(
            "اتصال از طریق «ADB روی شبکه» (هر دو دستگاه روی یک مودم وای‌فای):\n" +
            "۱. روی باکس: Settings ← About (درباره) ← ۷ بار روی Build number بزنید تا Developer options فعال شود.\n" +
            "۲. در Developer options گزینه‌ی USB debugging و در صورت وجود «ADB over network / Network debugging» را روشن کنید.\n" +
            "۳. آی‌پی باکس را از Settings ← Network یا About ← Status پیدا کنید و این‌جا وارد کنید (پورت معمولاً 5555).\n" +
            "۴. بار اول روی تلویزیون پیام «Allow USB debugging?» می‌آید؛ تیک Always allow را بزنید و OK کنید.\n\n" +
            "اگر باکس گزینه‌ی ADB شبکه ندارد: یک بار با کابل به کامپیوتر وصل کنید و دستور adb tcpip 5555 را بزنید."
        ))
        val ip = EditText(this).apply {
            hint = "آی‌پی باکس، مثلاً 192.168.1.50"
            setText(prefs.getString("adb_host", ""))
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(Color.WHITE); setHintTextColor(C_DIM); textDirection = View.TEXT_DIRECTION_LTR
            background = bg(C_CARD, 10); setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val port = EditText(this).apply {
            setText(prefs.getInt("adb_port", 5555).toString())
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE); textDirection = View.TEXT_DIRECTION_LTR
            background = bg(C_CARD, 10); setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        r.addView(ip, LinearLayout.LayoutParams(0, -2, 3f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        r.addView(port, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        col.addView(r)
        dialogStatus = statusBox(col)
        col.addView(row(46,
            btn("اتصال", C_ACCENT, 14f) {
                val h = ip.text.toString().trim()
                val p = port.text.toString().toIntOrNull() ?: 5555
                if (h.isEmpty()) return@btn toast("آی‌پی را وارد کنید")
                prefs.edit().putString("adb_host", h).putInt("adb_port", p).apply()
                adb.connectAsync(h, p)
            },
            btn("قطع", C_CARD2, 14f) { adb.disconnect() },
        ))
        col.addView(label("کارهای سریع (فقط وای‌فای):"))
        col.addView(row(44,
            btn("📱 اجرای برنامه‌ها", C_CARD, 14f) { showApps() },
            btn("⚙ تنظیمات باکس", C_CARD, 14f) { adb.shellAsync("am start -a android.settings.SETTINGS") },
        ))
        col.addView(row(44,
            btn("📶 تنظیمات وای‌فای", C_CARD, 14f) { adb.shellAsync("am start -a android.settings.WIFI_SETTINGS") },
            btn("🔵 تنظیمات بلوتوث", C_CARD, 14f) { adb.shellAsync("am start -a android.settings.BLUETOOTH_SETTINGS") },
        ))
        col.addView(row(44,
            btn("🔄 ریستارت باکس", C_RED, 14f) {
                confirm("باکس ریستارت شود؟") { adb.shellAsync("reboot") }
            },
        ))
        showDialog("اتصال وای‌فای", col)
    }

    private fun showApps() {
        if (!adb.connected) return toast("ابتدا وای‌فای را وصل کنید")
        toast("در حال دریافت فهرست برنامه‌ها…")
        adb.shellAsync("pm list packages -3") { out ->
            val pkgs = out?.lines()?.map { it.removePrefix("package:").trim() }?.filter { it.isNotEmpty() }?.sorted()
            if (pkgs.isNullOrEmpty()) return@shellAsync toast("فهرستی دریافت نشد")
            AlertDialog.Builder(this, DIALOG_THEME)
                .setTitle("اجرای برنامه روی باکس")
                .setItems(pkgs.toTypedArray()) { _, i -> launchApp(pkgs[i]) }
                .setNegativeButton("بستن", null)
                .show()
        }
    }

    private fun launchApp(pkg: String) {
        val cmd = "c=\$(cmd package resolve-activity --brief -c android.intent.category.LEANBACK_LAUNCHER $pkg | tail -n 1); " +
            "case \"\$c\" in */*) am start -n \"\$c\" ;; *) monkey -p $pkg -c android.intent.category.LAUNCHER 1 ;; esac"
        adb.shellAsync(cmd)
    }

    // ------------------------------------------------------------------ IR dialog
    private fun showIrDialog() {
        val col = dialogColumn()
        if (!ir.available) {
            col.addView(info("⚠ فرستنده‌ی مادون‌قرمز (IR) در این گوشی پیدا نشد."))
        }
        col.addView(info(
            "IR مثل ریموت اصلی کار می‌کند و تنها راهی است که باکسِ خاموش (Standby) را روشن می‌کند. گوشی را به طرف جلوی باکس بگیرید.\n" +
            "IR نمی‌تواند ماوس یا متن بفرستد؛ برای ایرماوس از بلوتوث استفاده کنید.\n\n" +
            "اگر پروفایل فعلی کار نکرد: «تست پروفایل‌ها» را بزنید. اگر هیچ‌کدام کار نکرد، با «اسکنر کد» کد هر دکمه را پیدا و ذخیره کنید."
        ))
        col.addView(label("پروفایل کدها:"))
        val spinner = Spinner(this)
        fun fillSpinner() {
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ir.all.map { it.name })
            spinner.setSelection(ir.selectedIndex)
        }
        fillSpinner()
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) { ir.selectedIndex = pos; refreshStatus() }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        col.addView(spinner)
        col.addView(row(44,
            btn("ارسال «خانه»", C_CARD, 14f) { if (!ir.send(RemoteKey.HOME)) toast("کد خانه در این پروفایل نیست") },
            btn("ارسال «پاور»", C_RED, 14f) { if (!ir.send(RemoteKey.POWER)) toast("کد پاور در این پروفایل نیست") },
        ))
        col.addView(row(44,
            btn("🧪 تست پروفایل‌ها", C_ACCENT, 14f) { profileWizard(0) { fillSpinner() } },
            btn("🔎 اسکنر کد", C_CARD2, 14f) { scannerDialog { fillSpinner() } },
        ))
        col.addView(row(44, btn("✏ ویرایش دستی کدها", C_CARD, 14f) { editCodesDialog { fillSpinner() } }))
        showDialog("ریموت مادون‌قرمز (IR)", col)
    }

    private fun profileWizard(i: Int, done: () -> Unit) {
        val presets = ir.presets
        if (i >= presets.size) {
            toast("هیچ پروفایل آماده‌ای جواب نداد؛ از «اسکنر کد» استفاده کنید")
            return
        }
        val p = presets[i]
        ir.send(RemoteKey.HOME, p)
        AlertDialog.Builder(this, DIALOG_THEME)
            .setTitle("تست ${i + 1} از ${presets.size}")
            .setMessage("دکمه‌ی «خانه» با پروفایل «${p.name}» ارسال شد.\nآیا باکس به صفحه‌ی اصلی رفت؟\n(اگر باکس خاموش است، «ارسال پاور» را بزنید)")
            .setPositiveButton("✔ بله، همین") { _, _ -> ir.selectedIndex = i; refreshStatus(); done(); toast("پروفایل «${p.name}» انتخاب شد") }
            .setNeutralButton("ارسال پاور") { _, _ -> ir.send(RemoteKey.POWER, p); profileWizard(i, done) }
            .setNegativeButton("بعدی ▶") { _, _ -> profileWizard(i + 1, done) }
            .show()
    }

    private fun scannerDialog(done: () -> Unit) {
        val base = ir.current
        var b0 = base.b0
        var b1 = base.b1
        var code = 0
        val keys = RemoteKey.entries
        val col = dialogColumn()
        col.addView(info(
            "۱. دکمه‌ای را که می‌خواهید پیدا کنید انتخاب کنید (برای شروع «خانه» یا «پاور» بهتر است).\n" +
            "۲. «بعدی» را بزنید و هر بار به تلویزیون نگاه کنید.\n" +
            "۳. وقتی باکس واکنش درست نشان داد، «ذخیره» را بزنید.\n" +
            "اگر ۲۵۶ کد را امتحان کردید و چیزی نشد، آدرس را عوض کنید (مثلاً 40 40، 00 FF، CC 1D، 01 FE)."
        ))
        val keySpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, keys.map { "${it.name} — ${it.label}" })
            setSelection(RemoteKey.HOME.ordinal)
        }
        col.addView(keySpinner)
        val addr = EditText(this).apply {
            setText("%02X %02X".format(b0, b1))
            setTextColor(Color.WHITE); textDirection = View.TEXT_DIRECTION_LTR
            background = bg(C_CARD, 10); setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        col.addView(label("آدرس (دو بایت هگز):"))
        col.addView(addr)
        val codeText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10))
        }
        fun show() { codeText.text = "کد: 0x%02X  (%d / 255)".format(code, code) }
        fun readAddr() {
            val parts = addr.text.toString().trim().split(' ', ',', ':').filter { it.isNotBlank() }
            if (parts.size >= 2) { parts[0].toIntOrNull(16)?.let { b0 = it }; parts[1].toIntOrNull(16)?.let { b1 = it } }
        }
        fun fire() { readAddr(); ir.sendRaw(b0, b1, code); show() }
        show()
        col.addView(codeText)
        val ltr = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        ltr.addView(row(48,
            btn("◀ قبلی", C_CARD, 14f) { code = (code + 255) % 256; fire() },
            btn("ارسال دوباره", C_CARD2, 14f) { fire() },
            btn("بعدی ▶", C_ACCENT, 14f) { code = (code + 1) % 256; fire() },
        ))
        col.addView(ltr)
        col.addView(row(46, btn("💾 ذخیره‌ی این کد برای دکمه‌ی انتخاب‌شده", C_GREEN, 14f) {
            readAddr()
            val p = ir.custom.copy("سفارشی")
            if (p.b0 != b0 || p.b1 != b1) {
                // Address changed: start the custom profile on the new address.
                p.codes.clear(); p.b0 = b0; p.b1 = b1
            }
            val key = keys[keySpinner.selectedItemPosition]
            p.codes[key] = code
            ir.saveCustom(p)
            refreshStatus(); done()
            toast("${key.name} = 0x%02X ذخیره شد (پروفایل «سفارشی»)".format(code))
        }))
        showDialog("اسکنر کد IR", col)
    }

    private fun editCodesDialog(done: () -> Unit) {
        val edit = EditText(this).apply {
            setText(ir.current.toText())
            setTextColor(Color.WHITE); typeface = Typeface.MONOSPACE; textSize = 13f
            textDirection = View.TEXT_DIRECTION_LTR; gravity = Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            background = bg(C_CARD, 10); setPadding(dp(10), dp(10), dp(10), dp(10))
            minLines = 10
        }
        val col = dialogColumn()
        col.addView(info("قالب: خط اول address=40 40 و بعد هر خط مثل POWER=B2 (هگز).\nنام دکمه‌ها: " + RemoteKey.entries.joinToString(", ") { it.name }))
        col.addView(edit)
        AlertDialog.Builder(this, DIALOG_THEME)
            .setTitle("ویرایش کدها (ذخیره در «سفارشی»)")
            .setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("ذخیره") { _, _ ->
                ir.saveCustom(IrProfile.parse("سفارشی", edit.text.toString()))
                refreshStatus(); done(); toast("ذخیره شد")
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ------------------------------------------------------------------ helpers
    private fun dialogColumn() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(16), dp(8), dp(16), dp(8))
    }

    private fun statusBox(col: LinearLayout): TextView {
        val t = TextView(this).apply {
            setTextColor(C_GREEN); textSize = 12f
            background = bg(C_BG, 8); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        col.addView(t, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) })
        refreshStatus()
        return t
    }

    private fun showDialog(title: String, content: View) {
        AlertDialog.Builder(this, DIALOG_THEME)
            .setTitle(title)
            .setView(ScrollView(this).apply { addView(content) })
            .setPositiveButton("بستن", null)
            .setOnDismissListener { dialogStatus = null }
            .show()
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(this, DIALOG_THEME).setMessage(msg)
            .setPositiveButton("بله") { _, _ -> yes() }.setNegativeButton("خیر", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int = 14): Drawable {
        val shape = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
        return RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), shape, null)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; setTextColor(C_DIM); textSize = 12f; setPadding(dp(2), dp(8), dp(2), dp(4))
    }

    private fun info(s: String) = TextView(this).apply {
        text = s; setTextColor(0xFFD0D6E2.toInt()); textSize = 13f; setPadding(0, dp(4), 0, dp(6))
        setLineSpacing(0f, 1.15f)
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(h)) }

    private fun weighted(h: Int) = LinearLayout.LayoutParams(0, dp(h), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }

    private fun row(h: Int, vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (v in views) addView(v, weighted(h))
    }

    private fun chip(text: String, onClick: () -> Unit) = btn(text, C_CARD, 13f, onClick)

    private fun btn(text: String, color: Int = C_CARD, textSize: Float = 15f, onClick: (() -> Unit)? = null) =
        TextView(this).apply {
            this.text = text
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            this.textSize = textSize
            background = bg(color)
            isClickable = true
            setPadding(dp(4), dp(2), dp(4), dp(2))
            if (onClick != null) setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                onClick()
            }
        }

    /** Remote key button; optional auto-repeat while held. */
    @SuppressLint("ClickableViewAccessibility")
    private fun keyBtn(key: RemoteKey, text: String = key.label, color: Int = C_CARD, repeat: Boolean = false, textSize: Float = 15f): TextView {
        val v = btn(text, color, textSize)
        var r: Runnable? = null
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.drawableHotspotChanged(e.x, e.y)
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    sendKey(key)
                    if (repeat) {
                        val run = object : Runnable {
                            override fun run() { sendKey(key); handler.postDelayed(this, 130) }
                        }
                        r = run
                        handler.postDelayed(run, 450)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    r?.let { handler.removeCallbacks(it) }
                    r = null
                }
            }
            true
        }
        return v
    }

    companion object {
        const val REQ_BT = 7
        val DIALOG_THEME = android.R.style.Theme_Material_Dialog_Alert
        val C_BG = 0xFF12151C.toInt()
        val C_CARD = 0xFF222836.toInt()
        val C_CARD2 = 0xFF2E3A50.toInt()
        val C_ACCENT = 0xFF3D8BFF.toInt()
        val C_RED = 0xFFD9434B.toInt()
        val C_GREEN = 0xFF2FB36B.toInt()
        val C_DIM = 0xFF8A96AD.toInt()
    }
}

/** Touch surface for touchpad mode / click & scroll in air-mouse mode. */
class TouchPadView(ctx: Context) : View(ctx) {
    var onDrag: ((Float, Float, Int) -> Unit)? = null
    var onTap: ((Int) -> Unit)? = null

    private var lastX = 0f
    private var lastY = 0f
    private var downTime = 0L
    private var moved = 0f
    private var maxFingers = 1
    private val d = resources.displayMetrics.density

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1A1F2B.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2E3A50.toInt(); style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF56627A.toInt(); textSize = 15 * d; textAlign = Paint.Align.CENTER }
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        rect.set(d, d, width - d, height - d)
        c.drawRoundRect(rect, 18 * d, 18 * d, fill)
        c.drawRoundRect(rect, 18 * d, 18 * d, stroke)
        c.drawText("صفحه‌ی لمسی", width / 2f, height / 2f, text)
    }

    private fun avgX(e: MotionEvent): Float { var s = 0f; for (i in 0 until e.pointerCount) s += e.getX(i); return s / e.pointerCount }
    private fun avgY(e: MotionEvent): Float { var s = 0f; for (i in 0 until e.pointerCount) s += e.getY(i); return s / e.pointerCount }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y; downTime = System.currentTimeMillis(); moved = 0f; maxFingers = 1
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                if (e.actionMasked == MotionEvent.ACTION_POINTER_DOWN) maxFingers = maxOf(maxFingers, e.pointerCount)
                // re-anchor to avoid jumps when finger count changes
                val upIdx = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
                var sx = 0f; var sy = 0f; var n = 0
                for (i in 0 until e.pointerCount) if (i != upIdx) { sx += e.getX(i); sy += e.getY(i); n++ }
                if (n > 0) { lastX = sx / n; lastY = sy / n }
            }
            MotionEvent.ACTION_MOVE -> {
                val x = avgX(e); val y = avgY(e)
                val dx = x - lastX; val dy = y - lastY
                lastX = x; lastY = y
                moved += abs(dx) + abs(dy)
                onDrag?.invoke(dx, dy, e.pointerCount)
            }
            MotionEvent.ACTION_UP -> {
                if (System.currentTimeMillis() - downTime < 250 && moved < 12 * d) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onTap?.invoke(maxFingers)
                }
            }
        }
        return true
    }
}
