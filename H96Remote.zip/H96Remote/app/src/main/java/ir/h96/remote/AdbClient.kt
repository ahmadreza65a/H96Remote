package ir.h96.remote

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.File
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.Executors
import javax.crypto.Cipher

/**
 * Minimal ADB-over-TCP client (classic "ADB over network", port 5555).
 * Lets the phone send any key / text / shell command to the box over Wi-Fi.
 */
class AdbClient(private val ctx: Context) {
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private var socket: Socket? = null
    private var input: DataInputStream? = null
    private var output: OutputStream? = null
    private var nextId = 1

    @Volatile var connected = false
        private set
    var host: String = ""
        private set
    var status: String = "وصل نیست"
        private set
    var onState: (() -> Unit)? = null

    private fun setStatus(s: String) { status = s; main.post { onState?.invoke() } }

    // ------------ public API ------------
    fun connectAsync(h: String, port: Int) {
        exec.execute {
            try {
                connectBlocking(h, port)
                host = h
                setStatus("متصل به $h")
            } catch (e: Exception) {
                closeQuietly()
                setStatus("اتصال ناموفق: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun disconnect() = exec.execute { closeQuietly(); setStatus("قطع شد") }

    fun shellAsync(cmd: String, done: ((String?) -> Unit)? = null) {
        exec.execute {
            val r = try { if (connected) shell(cmd) else null } catch (e: Exception) {
                closeQuietly(); setStatus("ارتباط قطع شد: ${e.message}"); null
            }
            if (done != null) main.post { done(r) }
        }
    }

    fun sendKey(k: RemoteKey): Boolean {
        if (!connected) return false
        shellAsync("input keyevent ${k.androidKey}")
        return true
    }

    fun keyCode(code: Int) { if (connected) shellAsync("input keyevent $code") }

    fun typeText(s: String) {
        if (!connected || s.isEmpty()) return
        // `input text` uses %s for spaces; wrap in single quotes for the shell.
        val escaped = s.replace("%", "\\%").replace(" ", "%s").replace("'", "'\\''")
        shellAsync("input text '$escaped'")
    }

    // ------------ protocol ------------
    private fun connectBlocking(h: String, port: Int) {
        closeQuietly()
        val s = Socket()
        s.connect(InetSocketAddress(h, port), 5000)
        s.tcpNoDelay = true
        s.soTimeout = 10000
        socket = s
        input = DataInputStream(s.getInputStream())
        output = s.getOutputStream()

        val keys = loadKeys()
        send(CNXN, 0x01000000, 256 * 1024, "host::\u0000".toByteArray())
        var sentSig = false
        while (true) {
            val m = read()
            when (m.cmd) {
                CNXN -> {
                    connected = true
                    s.soTimeout = 15000
                    return
                }
                AUTH -> if (m.a0 == 1) {
                    if (!sentSig) {
                        send(AUTH, 2, 0, sign(keys, m.data)); sentSig = true
                    } else {
                        send(AUTH, 3, 0, publicKeyBytes(keys.public as RSAPublicKey))
                        setStatus("روی تلویزیون پیام «Allow USB debugging» را تأیید کنید (تیک Always allow هم بزنید)")
                        s.soTimeout = 90000
                    }
                }
            }
        }
    }

    private fun shell(cmd: String): String {
        val id = nextId++
        send(OPEN, id, 0, "shell:$cmd\u0000".toByteArray())
        val out = ByteArrayOutputStream()
        while (true) {
            val m = read()
            if (m.a1 != id) continue
            when (m.cmd) {
                OKAY -> {}
                WRTE -> { out.write(m.data); send(OKAY, id, m.a0, null) }
                CLSE -> { send(CLSE, id, m.a0, null); break }
            }
        }
        return out.toString("UTF-8")
    }

    private class Msg(val cmd: Int, val a0: Int, val a1: Int, val data: ByteArray)

    private fun send(cmd: Int, a0: Int, a1: Int, data: ByteArray?) {
        val len = data?.size ?: 0
        val bb = ByteBuffer.allocate(24 + len).order(ByteOrder.LITTLE_ENDIAN)
        var sum = 0
        data?.forEach { sum += (it.toInt() and 0xFF) }
        bb.putInt(cmd).putInt(a0).putInt(a1).putInt(len).putInt(sum).putInt(cmd.inv())
        if (data != null) bb.put(data)
        output!!.write(bb.array())
        output!!.flush()
    }

    private fun read(): Msg {
        val head = ByteArray(24)
        input!!.readFully(head)
        val bb = ByteBuffer.wrap(head).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = bb.int; val a0 = bb.int; val a1 = bb.int; val len = bb.int
        val data = ByteArray(len)
        if (len > 0) input!!.readFully(data)
        return Msg(cmd, a0, a1, data)
    }

    private fun closeQuietly() {
        connected = false
        try { socket?.close() } catch (_: Exception) { }
        socket = null; input = null; output = null
    }

    // ------------ RSA keys (same scheme as the official adb) ------------
    private fun loadKeys(): KeyPair {
        val priv = File(ctx.filesDir, "adbkey")
        val pub = File(ctx.filesDir, "adbkey.pub")
        val kf = KeyFactory.getInstance("RSA")
        if (priv.exists() && pub.exists()) {
            try {
                return KeyPair(
                    kf.generatePublic(X509EncodedKeySpec(pub.readBytes())),
                    kf.generatePrivate(PKCS8EncodedKeySpec(priv.readBytes()))
                )
            } catch (_: Exception) { }
        }
        val gen = KeyPairGenerator.getInstance("RSA")
        gen.initialize(2048)
        val kp = gen.generateKeyPair()
        priv.writeBytes(kp.private.encoded)
        pub.writeBytes(kp.public.encoded)
        return kp
    }

    private fun sign(kp: KeyPair, token: ByteArray): ByteArray {
        val c = Cipher.getInstance("RSA/ECB/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, kp.private)
        c.update(SIGNATURE_PADDING)
        return c.doFinal(token)
    }

    private fun publicKeyBytes(pub: RSAPublicKey): ByteArray {
        val r32 = BigInteger.ZERO.setBit(32)
        var n = pub.modulus
        val r = BigInteger.ZERO.setBit(2048)
        var rr = r.modPow(BigInteger.valueOf(2), n)
        val n0inv = n.remainder(r32).modInverse(r32)
        val nArr = IntArray(64); val rrArr = IntArray(64)
        for (i in 0 until 64) {
            var res = rr.divideAndRemainder(r32); rr = res[0]; rrArr[i] = res[1].toInt()
            res = n.divideAndRemainder(r32); n = res[0]; nArr[i] = res[1].toInt()
        }
        val bb = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(64)
        bb.putInt(r32.subtract(n0inv).toInt())
        nArr.forEach { bb.putInt(it) }
        rrArr.forEach { bb.putInt(it) }
        bb.putInt(pub.publicExponent.toInt())
        val b64 = Base64.encodeToString(bb.array(), Base64.NO_WRAP)
        return "$b64 h96remote@phone\u0000".toByteArray()
    }

    companion object {
        private const val CNXN = 0x4e584e43
        private const val AUTH = 0x48545541
        private const val OPEN = 0x4e45504f
        private const val OKAY = 0x59414b4f
        private const val CLSE = 0x45534c43
        private const val WRTE = 0x45545257

        private val SIGNATURE_PADDING: ByteArray = run {
            val head = intArrayOf(0x00, 0x01)
            val ff = IntArray(218) { 0xFF }
            val tail = intArrayOf(
                0x00, 0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
            )
            (head + ff + tail).map { it.toByte() }.toByteArray()
        }
    }
}
