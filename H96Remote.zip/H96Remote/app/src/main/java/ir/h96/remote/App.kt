package ir.h96.remote

import android.app.Application
import android.content.Context
import android.content.SharedPreferences

class App : Application() {
    lateinit var prefs: SharedPreferences
    lateinit var ir: IrRemote
    lateinit var hid: HidRemote
    lateinit var adb: AdbClient

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = getSharedPreferences("remote", Context.MODE_PRIVATE)
        ir = IrRemote(this, prefs)
        hid = HidRemote(this, prefs)
        adb = AdbClient(this)
    }

    companion object {
        lateinit var instance: App
            private set
    }
}
